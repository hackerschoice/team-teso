
	BITS 32

	org	0x08048000

ehdr:					; Elf32_Ehdr
	db      0x7F, "ELF", 1, 1, 1	;  e_ident
	times 9	db	0
	dw	2			;  e_type
	dw	3			;  e_machine
	dd	1			;  e_version
	dd	_start			;  e_entry
	dd	phdr - $$		;  e_phoff
	dd	0			;  e_shoff
	dd	0			;  e_flags
	dw	ehdrsize		;  e_ehsize
	dw	phdrsize		;  e_phentsize
	dw	1			;  e_phnum
	dw	0			;  e_shentsize
	dw	0			;  e_shnum
	dw	0			;  e_shstrndx

ehdrsize	equ	($ - ehdr)

phdr:				; Elf32_Phdr
	dd	1		;  p_type
	dd	0		;  p_offset
	dd	$$		;  p_vaddr
	dd	$$		;  p_paddr
	dd	filesize	;  p_filesz
	dd	filesize	;  p_memsz
	dd	5		;  p_flags
	dd	0x1000		;  p_align

phdrsize	equ	($ - phdr)

; fd 0 = random file
; fd 1 = output file
_start:
	int3

	xchg	word [ebx], bx


	xchg	word [bx], bx


	nop
	xchg	word [bx], bx
	xchg	word [bx + si], bx
	nop

	mov	eax, dword [bx + si + 0x0102]

	mov	bx, word [ebx]
	mov	cx, dx

	wait
	wbinvd
	wrmsr
	xadd	eax, ebx
	xadd	dl, cl
	xchg	eax, edx
	xchg	byte [eax], dl
	xlat
	xor	ebx, 0x41424344
	xor	byte [0x41424344], 0xf0

	nop

	shld	edx, eax, 12
	shrd	ebx, ecx, cl
	shr	eax, cl
	sidt	[phdr]
	stc
	std
	sti
	stosd
	str	[phdr]
	sub	eax, 8
	sub	ecx, edx
	test	al, 0xff

	db	0x0f
	db	0x0b
	verr	[eax]
	verw	[phdr]

	nop

	ret
	ret	0x0102
	rol	eax, 1
	rol	edx, cl
	ror	eax, 12
	rsm
	sahf
	sbb	eax, edx
	sbb	dl, 10
	scasb
	setz	al
	shl	ebx, cl

	nop

	pop	cs	; uhh ohh

	pop	ds
	pop	gs
	popa
	popf
	push	eax
	push	0x41
	push	0x41424344
	push	ds
	push	fs
	pusha
	pushf
	rcl	ebx, 1
	rcl	eax, cl
	rcl	edx, 4
	rcr	ebx, 3
	rdmsr
	rdpmc
	rdtsc

	nop

	movsx	eax, dl
	movsb
	movsd
	movzx	edx, byte [0x41424344]
	mul	edx
	neg	al
	nop
	not	dword [0x41424344]
	or	edx, dword [4*eax + 0x41424344]
	out	0x60, al
	out	dx, eax
	outs
	pop	eax
	pop	dword [0x41424344]


	nop

	mov	cs, eax
	mov	ebx, ds
	mov	cs, word [0x41424344]
	mov	word [0x46474849], es
	mov	ss, ecx

	nop

	mov	cr0, eax
	mov	eax, cr1
	mov	dr6, edx
	mov	ecx, dr7

	nop

	lsl	ebx, [eax]
	mov	ebx, eax
	mov	cl, ch
	mov	dl, 0x61
	mov	edx, 0x61616161
	mov	[0x41424344], eax
	mov	eax, [0x81828384]

	nop

	lahf
	lar	eax, ebx
	lar	ecx, [eax]
	lea	eax, [4*ecx]
	leave
	nop
	lgdt	[ebx]
	lldt	[ecx]
	lmsw	[edx]
	lodsb
	loop	label2

	nop

	jns	label2
label2:	jmp	eax

	db	0xea
	dd	0x01020304
	dw	0x4041
	nop
	jmp	[eax]
	jmp	dword [0x41424344]

	nop

	in	eax, 0x60
	in	eax, dx
	inc	eax
	nop
	int3
	int	0x80
	iret

	nop

	imul	ebx, dword [0x41424344]
	imul	ecx, [eax], 100

	enter	0x100, 1
	nop

	div	dl
	div	dword [0x41424344]

	nop
	dec	eax
	dec	dword [eax]
	dec	byte [0x41424344]
	nop

	cmpsb
	cmpsd
	cmpxchg	eax, ebx
	cmpxchg8b	[0x41424344]

	nop

	cmp	eax, 0x10203040

	cmp	byte [0x41424344], ah
	cmp	ah, bh
	nop

	cmp	eax, ebx
	cmp	al, bl

	nop

	cmovns	eax, ebx

	nop

	cbw
	cdq
	clc
	cld
	cli
	clts
	cmc

	call	label
	nop
	db	0x9a
	dd	0x40414243
	dw	0x1234

	call	dword 0x08048000

label:

	btc	eax, ebx

	bt	eax, ebx
	nop
	bt	eax, 0x7f

	nop

	add	eax, 0x10203040

	bsf	eax, ebx
	nop
	bsf	eax, [edx * 8]
	nop
	bswap	eax

	nop

	add	eax, [edx * 8 + eax]

	nop
	add	[edx*2 + ecx + 0x41424344], ebx

	add	[eax*2+edx], ebx
	nop
	mov	[eax], ebx


doexit:	mov	eax, 1
	xor	ebx, ebx	; exit with level 0
	int	0x80

filesize	equ	($ - $$)


