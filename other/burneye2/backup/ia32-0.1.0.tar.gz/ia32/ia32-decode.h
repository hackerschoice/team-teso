/* ia32-decode.h - ia32 decoding library
 * include file
 *
 * by scut
 */

#ifndef	IA32_DECODE_H
#define	IA32_DECODE_H

/* single table element. always static and readonly
 */
typedef struct {
	char *		name;	/* prefix name */
	unsigned char	code;

#define	RELACT_OVERRIDE	1
#define	RELACT_COMBINE	2
	unsigned int	relact;	/* action to take when encountering prefix */
#define	PFX_RELOFS(selem) ((unsigned int)(&(((ia32_prefix *)(0))->selem)))
#define	PFX_ABS(str,relofs) ((unsigned int *)(((char *)(str))+(relofs)))
	unsigned int	relptr;	/* relative pointer into ia32_prefix struct */
	unsigned int	relval;	/* value to operate with */
} ia32_prefix_e;


typedef struct {
	unsigned int	length;		/* overall prefix length */
#define	IA32_PREFIX_MAX	15
	ia32_prefix_e *	prefix[16];	/* ptrs into prefix tab, NULL termtd */

	unsigned int	lock;		/* lock prefix used */
#define	IA32_PREFIX_REPNE	1
#define	IA32_PREFIX_REPNZ	IA32_PREFIX_REPNE
#define	IA32_PREFIX_REP		2
#define	IA32_PREFIX_REPE	3
#define	IA32_PREFIX_REPZ	IA32_PREFIX_REPE
	unsigned int	rep;		/* rep prefixes */
#define	IA32_SEG_CS	0x01
#define	IA32_SEG_SS	0x02
#define	IA32_SEG_DS	0x04
#define	IA32_SEG_ES	0x08
#define	IA32_SEG_FS	0x10
#define	IA32_SEG_GS	0x20
#define	IA32_SEG_SIZE	16
	unsigned int	seg;		/* segment prefixes */

	unsigned int	oper_size;	/* operand size override */
	unsigned int	addr_size;	/* address size override */
} ia32_prefix;


/* the register value used to denote direct memory access in the mod r/m byte
 */
#define	IA32_RM_SIB		0x04
#define	IA32_MOD00_RM_DIRECT	0x05

#define	IA32_REG_EAX	0x00


typedef struct {
	char *		name;		/* name of instruction */

	/* width flag applies to only the target operand, else to both,
	 * source and target (OD_WTONLY: movsx, ..) */
#define	OD_WTONLY	(1 << 0)
#define	OD_JUMP		(1 << 1)
#define	OD_IMM		(1 << 2)
#define	OD_IMMSIZE_MASK	0070
#define	OD_IMMSIZE_SET(n)	((n) << 3)
#define	OD_IMMSIZE_GET(fl)	((fl) & OD_IMMSIZE_MASK)
#define	OD_IMMSIZE_8	OD_IMMSIZE_SET(001)
#define	OD_IMMSIZE_16	OD_IMMSIZE_SET(002)
#define	OD_IMMSIZE_32	OD_IMMSIZE_SET(003)
#define	OD_IMMSIZE_WORD	OD_IMMSIZE_SET(004)
	/* hardcoded target register eax */
#define	OD_REG_HARD_EAX	(1 << 6)
#define	OD_REG12_REV	(1 << 7)
	/* contains full displacement (like immediate), for call */
#define	OD_IMM_DISPL	(1 << 8)
#define	OD_IMM_DISPL_8	(1 << 9)
#define	OD_IMM_DISPL_16	(1 << 10)
#define	OD_IMM_DISPL_WORD	(1 << 11)
#define	OD_IMM_OFFSET	(1 << 12)
	/* immediate selector (16 bit) */
#define	OD_IMM_SELECT	(1 << 13)
	/* OD_WIDTH_LOCK = do not modify the length after instruction
	 * processing. this is used when the length is more complex and has to
	 * be processed seperatly within the decoder. eg. when segment
	 * registers are moved, this is used.
	 */
#define	OD_WIDTH_LOCK	(1 << 14)
	/* OD_WIDTH_WIDE = always assume operations on the current wide size,
	 * 16 or 32 bits that is, depending on the cpu state. this can be
	 * overriden with prefixes.
	 */
#define	OD_WIDTH_WIDE	(1 << 15)
	/* double wide (64 bit, edx:eax) */
#define	OD_WIDTH_DWIDE	(1 << 16)
	/* kludge: _LWIDE = extend the last target operand to wordsize, after
	 * all swapping has taken place. required for extension instructions,
	 * such as movsx and movzx
	 */
#define	OD_WIDTH_LWIDE	(1 << 17)
	/* _CR = the special registers in the opcode are CR regs */
#define	OD_CR		(1 << 18)
	/* _DR = the special registers in the opcode are DR regs */
#define	OD_DR		(1 << 19)
	unsigned int	flags;

	/* main opcode encoding specifications
	 * structure:
	 *
	 * ++++.++++.++++.++++.++++.++++.++++.++++
	 * |                   <-cmask-> <-cval ->
	 * |
	 * |
	 * +--- OD_END marker, exclusivly set
	 */
	unsigned int	opc[8];
#define	OD_END		(1 << 31)
#define	OD_CMASK	0x0000ff00
#define	OD_CVAL		0x000000ff
#define	OD_CVAL_GET(o)	((o) & OD_CVAL)
#define	OD_CMASK_SET(m)	((m) << 8)
#define	OD_CMASK_GET(o)	(((o) & OD_CMASK) >> 8)
	/* common cases of masks */
#define	OD_FIX		OD_CMASK_SET(0xff)
#define	OD_FIX_2	OD_CMASK_SET(0xc0)
#define	OD_FIX_4	OD_CMASK_SET(0xf0)
#define	OD_FIX_5	OD_CMASK_SET(0xf8)
#define	OD_FIX_543	OD_CMASK_SET(0x38)
#define	OD_FIX_6	OD_CMASK_SET(0xfc)
#define	OD_FIX_7	OD_CMASK_SET(0xfe)
#define	OD_FIX_68	OD_CMASK_SET(0xfd)
#define	OD_TEST(o,f)	(((o) & (f)) == (f))
	/* has w flag (bit 0) */
#define	OD_W		(1 << 16)
#define	OD_W_MASK	0x01
	/* has w flag (as bit 3), eg. mov */
#define	OD_W3		(1 << 17)
#define	OD_W3_MASK	0x08
	/* has s flag (bit 1) */
#define	OD_S		(1 << 18)
#define	OD_S_MASK	0x02
	/* has tttn flags (bits 3210) */
#define	OD_TTTN		(1 << 19)
#define	OD_TTTN_MASK	0x0f
	/* has mod specifier (bits 76) */
#define	OD_MOD		(1 << 20) 
#define	OD_MOD_MASK	0xc0
	/* has r/m specifier (bits 210) */
#define	OD_RM		OD_MOD
#define	OD_RM_MASK	0x07
	/* reg1 given (bits 543) */
#define	OD_REG1		(1 << 21)
	/* reg2 given (bits 210) */
#define	OD_REG2		(1 << 22)
#define	OD_REG2_MASK	0x07
#define	OD_REG12	(OD_REG1 | OD_REG2)
	/* lreg = lower register, for simple instructions, bits 210 */
#define	OD_LREG		OD_REG2
#define	OD_LREG_MASK	OD_REG2_MASK
	/* normal register position for mod reg r/m */
#define	OD_REG		OD_REG1
#define	OD_REG_MASK	0x38
#define	OD_MODREGRM	(OD_MOD | OD_REG | OD_RM)
#define	OD_MODRM	(OD_MOD | OD_RM)

	/* sreg2, bits 43 */
#define	OD_SREG2	(1 << 23)
#define	OD_SREG2_MASK	0x18
	/* sreg3, bits 543 */
#define	OD_SREG3	(1 << 24)
#define	OD_SREG3_MASK	OD_REG_MASK
	/* special purpose register field, bits 543 */
#define	OD_EEE		(1 << 25)
#define	OD_EEE_MASK	0x38

} ia32_opcode_e;

#define	OD_SET_COND(in,mask) ((((in) & (mask)) != 0) ? 1 : 0)


typedef struct {
	unsigned int	length;	/* total length, from opcode to next prefix */
	ia32_opcode_e *	opcode;	/* pointer into opcode table */

	/* stored here for convenience of lower level decoding functions
	 */
	unsigned char	modbyte,
			sibbyte;

#define	OP_SOURCE	0x01
#define	OP_TARGET	0x02
#define	OP_IMMEDIATE	0x04
#define	OP_DISPLACE	0x08
#define	OP_SIB		0x10
#define	OP_JUMP		0x20
#define	OP_COND		0x40
#define	OP_SELECTOR	0x80
	unsigned int	used;	/* what kind of elements from below are used */

	unsigned int	cond;	/* in case of a conditional instruction */

	/* when this is set, the order of source/target operands was reversed
	 * in the instruction. however, the source_* and target_* values below
	 * always denote the real source and target. this can be used for
	 * re-encoding the instruction though :)
	 */
	unsigned int	reversed;
	/* when a W flag was present in the instruction, this is copied over.
	 * this is necessary to not lose information when decoding instructions
	 * without explicit source/target operands, such as lods, movs, which
	 * could be lods[bd].
	 */
	unsigned int	wide;

#define	OP_TYPE_UNUSED	0x00
#define	OP_TYPE_REG	0x01
	/* _MEM = SIB addressing
	 * _MEMABS = one 32 bit offset
	 * _MEMREG = normal non-SIB addressing
	 */
#define	OP_TYPE_MEM	0x02
#define	OP_TYPE_MEMABS	0x03
#define	OP_TYPE_MEMREG	0x04
	/* _IMM = immediate data
	 * _DISPL = displacement, for call/jump
	 * _OFFSET = wide offset in immidiate
	 * _SPECIAL = special register or other
	 */
#define	OP_TYPE_IMM	0x05
#define	OP_TYPE_DISPL	0x06
#define	OP_TYPE_OFFSET	0x07
	/* _CR = control registers (cr0-cr4)
	 * _DR = debug registers (dr0-dr7)
	 * _SEG = segment registers (0-7, es,cs,ss,ds,fs,gs,reserved,reserved
	 */
#define	OP_TYPE_SPEC_CR	0x08
#define	OP_TYPE_SPEC_DR	0x09
#define	OP_TYPE_SPEC_SEG	0x0a
	unsigned int	source_type;	/* source operand type */
	unsigned int	source_reg;
	unsigned int	source_width;	/* 32, 16 or 8 (bits) */
	unsigned int	target_type;
	unsigned int	target_reg;
	unsigned int	target_width;	/* 32, 16 or 8 (bits) */

	/* SIB byte, addr = base + (scale * index) */
	unsigned int	scale;		/* 0,1,2,3 */
	unsigned int	index;		/* index used? 0/1 */
	unsigned int	index_reg;	/* index = 1: register number */
	unsigned int	base;		/* base used? 0/1 */
	unsigned int	base_reg;	/* base = 1: register number */

	/* displacement */
	unsigned int	displ_size;
	unsigned int	displ_value;
	unsigned short	selector;	/* 16 bit word selector */

	/* immediate data, also used for offset (32) and levels (8 bit) */
	unsigned int	imm_size;
	unsigned int	imm_value;
} ia32_opcode;


/* one single instruction, made up from a prefix and an opcode
 */

typedef struct {
	void *		user;	/* user-useable structure */
	int		length;	/* pfx->length + opc->length */
	ia32_prefix	pfx;
	ia32_opcode	opc;
} ia32_instruction;


/* ia32_decode_instruction
 *
 * decode a single instruction at `input'. when `new' is non-NULL it will be
 * recycled, otherwise one ia32_instruction structure is allocated.
 *
 * return pointer to decoded structure on success
 * return NULL on failure
 */

ia32_instruction *
ia32_decode_instruction (unsigned char *input, ia32_instruction *new);


/* ia32_decode_prefix
 *
 * decode the beginning of an instruction at `input', trying to locate prefix
 * bytes. when `new' is NULL, a new structure will be allocated, else the old
 * one will be recycled, the old data is lost.
 *
 * return a pointer to the prefix structure on success
 * return NULL when no prefix has been found
 */

ia32_prefix *
ia32_decode_prefix (unsigned char *input, ia32_prefix *new);


/* ia32_decode_opcode
 *
 * decode the opcode part of an instruction at `input' into an ia32_opcode
 * structure. if `new' is non-NULL it will be resetted and recycled, else
 * a new structure is allocated. the prefix part of the instruction can be
 * passed through the `pfx' pointer, and is used to obey size prefixes. when
 * NULL is passed, the default lengths are used.
 *
 * return a pointer to the decoded opcode structure
 */

ia32_opcode *
ia32_decode_opcode (unsigned char *input, ia32_opcode *new,
	ia32_prefix *pfx);


/* ia32_print
 *
 * print a string representation of the instruction `inst'.
 *
 * return in any case
 */

void
ia32_print (ia32_instruction *inst);

#endif


