/* libxelf - symbol information abstraction module
 *
 * by scut / teso
 */

#ifndef	ELF_SYMBOL_H
#define	ELF_SYMBOL_H

#include <elf.h>
#include "elf_section.h"


/* elf_symbol structure that can be used as linked list
 */
typedef struct elf_symbol {
	struct elf_symbol *	next;	/* next element or NULL for end */
	Elf32_Sym		sent;
} elf_symbol;


typedef struct {
	elf_section *	symtab;
	elf_section *	symtab_str;
} elf_symtab;

#endif

