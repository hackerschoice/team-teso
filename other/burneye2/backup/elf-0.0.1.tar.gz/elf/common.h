
#ifndef	Z_COMMON_H
#define	Z_COMMON_H

#include <stdio.h>

#ifdef	DEBUG
void	debugp (char *filename, const char *str, ...);
void	hexdump (char *filename, unsigned char *data, unsigned int amount);
#endif
void			*xrealloc (void *m_ptr, size_t newsize);
char			*xstrdup (char *str);
void			*xcalloc (int factor, size_t size);

#endif

