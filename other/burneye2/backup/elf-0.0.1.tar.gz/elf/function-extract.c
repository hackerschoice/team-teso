/* donkey-fix, be an associal nerd
 */

#include <elf.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <ia32-decode.h>
#include "common.h"
#include "elf_file.h"
#include "elf_section.h"
#include "elf_symbol.h"
#include "elf_dump.h"


extern dump_header	dh_Shdr_short[];
extern dump_header	dh_Shdr[];


void
function_dump (elf_file *elf, elf_section_list *slist, char *func_name,
	char *section_name, unsigned int relofs, unsigned int relsize);

int	dump_asm = 1;
char *	progname;
char *	binary;


void
usage (char *name)
{
	fprintf (stderr, "usage: %s <binary>\n\n",
		progname);

	exit (EXIT_FAILURE);
}



int
main (int argc, char *argv[])
{
	char			c;
	int			i;
	elf_file *		elf;
	elf_section *		sect;
	elf_section *		symtab_str;
	elf_section_list *	slist;
	elf_section *		symtab;
	Elf32_Sym		sent;


	progname = argv[0];

	if (argc < 2)
		usage (progname);

	while ((c = getopt (argc, argv, "")) != EOF) {
		switch (c) {
		default:
			usage (progname);
			break;
		}
	}

	binary = argv[argc - 1];
	if (binary[0] == '-')
		usage (progname);

	elf = elf_file_load (binary);
	if (elf == NULL) {
		fprintf (stderr, "failed.\n");
		exit (EXIT_FAILURE);
	}

	slist = elf_section_list_create ();

	for (i = 0 ; i < elf->Ehdr.e_shnum ; ++i) {
		sect = elf_section_load (elf, i, &elf->Shdr[i]);
		elf_section_list_add (slist, sect);
	}

	elf_section_list_sort (slist);


	/* find functions
	 */
	symtab = elf_section_list_find_type (slist, SHT_SYMTAB);
	if (symtab == NULL) {
		fprintf (stderr, "binary has no symbol table\n");
		exit (EXIT_FAILURE);
	}

	symtab_str = elf_section_list_find_index (slist, symtab->Shdr.sh_link);
	if (symtab_str == NULL) {
		fprintf (stderr, "binary has no string table for symbol section\n");
		exit (EXIT_FAILURE);
	}

	printf ("\n");
	printf ("symbol table: (%2lu: %s)  string table: (%2lu: %s)\n",
		symtab->sh_idx, &elf->sh_str[symtab->Shdr.sh_name],
		symtab_str->sh_idx, &elf->sh_str[symtab_str->Shdr.sh_name]);

	/* TODO: move code outa here to elf_symbol.[ch]
	 */
	for (i = 0 ; i < symtab->Shdr.sh_size ; i += sizeof (sent)) {
		memcpy (&sent, &symtab->data[i], sizeof (sent));
		if (ELF32_ST_TYPE (sent.st_info) == STT_FUNC) {
			printf ("%-32s | %-12s | 0x%08lx - 0x%08lx (0x%08lx)\n",
				&symtab_str->data[sent.st_name],
				elf_section_name (elf, elf_section_list_find_index (slist, sent.st_shndx)),
				(unsigned long int) sent.st_value,
				(unsigned long int) (sent.st_value + sent.st_size),
				(unsigned long int) sent.st_size);

			if (dump_asm)
				function_dump (elf, slist,
					&symtab_str->data[sent.st_name],
					elf_section_name (elf,
						elf_section_list_find_index
						(slist, sent.st_shndx)),
					(unsigned int) sent.st_value,
					(unsigned int) sent.st_size);

		}
	}

	elf_section_list_destroy (slist);
	elf_file_destroy (elf);

	exit (EXIT_SUCCESS);
}


void
function_dump (elf_file *elf, elf_section_list *slist, char *func_name,
	char *section_name, unsigned int relofs, unsigned int relsize)
{
	int		i;
	elf_section *	sect = NULL;
	FILE *		fp;
	char		outname[128];


	for (i = 0 ; i < elf->Ehdr.e_shnum ; ++i) {
		if (strcmp (&elf->sh_str[slist->list[i]->Shdr.sh_name],
			section_name) != 0)
			continue;

		sect = slist->list[i];

		fprintf (stderr, "%2d (%2lu): ", i, slist->list[i]->sh_idx);
		elf_dump_desc (elf, dh_Shdr_short,
			(void *) &slist->list[i]->Shdr.sh_name,
			elf->Ehdr.e_shentsize);
		fprintf (stderr, "| %s\n",
			&elf->sh_str[slist->list[i]->Shdr.sh_name]);
	}

	if (sect == NULL)
		return;

	printf ("section start = 0x%08x\n", sect->Shdr.sh_addr);
	relofs -= sect->Shdr.sh_addr;
	if (sect->Shdr.sh_type != SHT_PROGBITS)
		return;

	if (sect == NULL) {
		fprintf (stderr, "unable to find %s\n", section_name);

		return;
	}

	i = 0;

	snprintf (outname, sizeof (outname), "%s.bin", func_name);
	outname[sizeof (outname) - 1] = '\0';

	fp = fopen (outname, "wb");
	fwrite (sect->data + relofs, 1, relsize, fp);
	fclose (fp);

	snprintf (outname, sizeof (outname), "%s.asm", func_name);
	outname[sizeof (outname) - 1] = '\0';

	fp = fopen (outname, "w");
	fprintf (fp, "0x%04x+", relofs);

	while (i < relsize && (i + relofs) < sect->data_len) {
		ia32_instruction *	inst,
					inst_s;
		char			inst_str[128];

		inst = ia32_decode_instruction (&sect->data[i + relofs], &inst_s);
		if (inst == NULL) {
			fprintf (fp, "INVALID\n");

			return;
		}

		fprintf (fp, "\t0x%04x", i);
		ia32_sprint (inst, inst_str, sizeof (inst_str));
		fprintf (fp, "%s\n", inst_str);

		i += inst->length;
	}

	fprintf (fp, "\n");
	fclose (fp);
}

