/* ia32-decode.c - ia32 decoding library
 *
 * by scut
 *
 * 2002/08/03
 *
 * TODO: 3. add "OP_CONTROL" flag, to mark instructions that can affect the
 * 	    programs control flow.
 * 	 1. check with latest opcode tables, add missing.
 * 	 2. add jcc prefix handling (0x2e/0x3e branch prefixes, invalidate all
 * 	    other segment prefixes)
 * 	 4. tidy up the string representation function
 * 	 5. fix all other TODO/FIXME's in the source
 */

#define	VERSION "0.1.3"


#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ia32-decode.h"


ia32_prefix_e	ia32_prefix_table[] = {
	{ "lock", 0xf0, RELACT_OVERRIDE, PFX_RELOFS (lock), 1 },
	{ "repne", 0xf2, RELACT_OVERRIDE, PFX_RELOFS (rep), IA32_PREFIX_REPNE },
	{ "rep", 0xf3, RELACT_OVERRIDE, PFX_RELOFS (rep), IA32_PREFIX_REP },
	{ "cs", 0x2e, RELACT_COMBINE, PFX_RELOFS (seg), IA32_SEG_CS },
	{ "ss", 0x36, RELACT_COMBINE, PFX_RELOFS (seg), IA32_SEG_SS },
	{ "ds", 0x3e, RELACT_COMBINE, PFX_RELOFS (seg), IA32_SEG_DS },
	{ "es", 0x26, RELACT_COMBINE, PFX_RELOFS (seg), IA32_SEG_ES },
	{ "fs", 0x64, RELACT_COMBINE, PFX_RELOFS (seg), IA32_SEG_FS },
	{ "gs", 0x65, RELACT_COMBINE, PFX_RELOFS (seg), IA32_SEG_GS },
	{ "oper", 0x66, RELACT_OVERRIDE, PFX_RELOFS (oper_size), 1 },
	{ "addr", 0x67, RELACT_OVERRIDE, PFX_RELOFS (addr_size), 1 },
	{ NULL, 0, 0, 0, 0 },
};

unsigned int	ia32_prefix_tabsize =
	(sizeof (ia32_prefix_table) / sizeof (ia32_prefix_e)) - 1;


	/* TODO: move this table to an extra file, once it is complete */
ia32_opcode_e	ia32_opcode_table[] = {
	{ "aaa", 0, { OD_FIX | 0x37, OD_END } },
	{ "aad", 0, { OD_FIX | 0xd5, OD_FIX | 0x0a, OD_END } },
	{ "aam", 0, { OD_FIX | 0xd4, OD_FIX | 0x0a, OD_END } },
	{ "aas", 0, { OD_FIX | 0x3f, OD_END } },

	{ "adc", 0, { OD_FIX_6 | OD_D | OD_W | 0x10, OD_MODREGRM, OD_END } },
	{ "adc", OD_IMM, { OD_FIX_6 | OD_S | OD_W | 0x80,
		OD_FIX_543 | OD_MODRM | 0x10, OD_END } },
	{ "adc", OD_IMM | OD_REG_HARD_EAX,
		{ OD_FIX_7 | OD_W | 0x14, OD_END } },

	{ "add", 0, { OD_FIX_6 | OD_D | OD_W | 0x00, OD_MODREGRM, OD_END } },
	{ "add", OD_IMM, { OD_FIX_6 | OD_S | OD_W | 0x80,
		OD_FIX_543 | OD_MODRM | 0x00, OD_END } },
	{ "add", OD_IMM | OD_REG_HARD_EAX,
		{ OD_FIX_7 | OD_W | 0x04, OD_END } },

	{ "and", 0, { OD_FIX_6 | OD_D | OD_W | 0x20, OD_MODREGRM, OD_END } },
	{ "and", OD_IMM | OD_IMMSIZE_WORD | OD_REG_HARD_EAX,
		{ OD_FIX_7 | OD_W | 0x24, OD_END } },
	{ "and", OD_IMM | OD_IMMSIZE_WORD, { OD_FIX_6 | OD_S | OD_W | 0x80,
		OD_FIX_543 | OD_MODRM | 0x20, OD_END } },

	{ "arpl", 0, { OD_FIX | 0x63, OD_MODREGRM, OD_END } },
	{ "bound", 0, { OD_FIX | 0x62, OD_MODREGRM, OD_END } },
	{ "bsf", OD_WIDTH_WIDE | OD_REG12_REV,
		{ OD_FIX | 0x0f, OD_FIX | 0xbc, OD_MODREGRM, OD_END } },
	{ "bsr", OD_WIDTH_WIDE | OD_REG12_REV,
		{ OD_FIX | 0x0f, OD_FIX | 0xbd, OD_MODREGRM, OD_END } },
	{ "bswap", OD_WIDTH_WIDE,
		{ OD_FIX | 0x0f, OD_FIX_5 | OD_LREG | 0xc8, OD_END } },

	{ "bt", OD_WIDTH_WIDE | OD_IMM | OD_IMMSIZE_8,
		{ OD_FIX | 0x0f, OD_FIX | 0xba, OD_FIX_543 | OD_MODRM | 0x20,
		OD_END } },
	{ "bt", OD_WIDTH_WIDE,
		{ OD_FIX | 0x0f, OD_FIX | 0xa3, OD_MODREGRM, OD_END } },

	{ "btc", OD_IMM | OD_IMMSIZE_8, { OD_FIX | 0x0f, OD_FIX | 0xba,
		OD_FIX_543 | OD_MODRM | 0x38, OD_END } },
	{ "btc", OD_WIDTH_WIDE,
		{ OD_FIX | 0x0f, OD_FIX | 0xbb, OD_MODREGRM, OD_END } },

	{ "btr", OD_IMM | OD_IMMSIZE_8, { OD_FIX | 0x0f, OD_FIX | 0xba,
		OD_FIX_543 | OD_MODRM | 0x30, OD_END } },
	{ "btr", OD_WIDTH_WIDE,
		{ OD_FIX | 0x0f, OD_FIX | 0xb3, OD_MODREGRM, OD_END } },

	{ "bts", OD_IMM | OD_IMMSIZE_8, { OD_FIX | 0x0f, OD_FIX | 0xba,
		OD_FIX_543 | OD_MODRM | 0x28, OD_END } },
	{ "bts", OD_WIDTH_WIDE,
		{ OD_FIX | 0x0f, OD_FIX | 0xab, OD_MODREGRM, OD_END } },

	{ "call", OD_IMM_DISPL | OD_IMM_DISPL_WORD, { OD_FIX | 0xe8, OD_END } },
	{ "call", 0, { OD_FIX | 0xff, OD_FIX_543 | OD_MODRM | 0x10, OD_END } },
	{ "call", OD_IMM_OFFSET | OD_IMMSIZE_WORD | OD_IMM_SELECT,
		{ OD_FIX | 0x9a, OD_END } },
	{ "call", 0, { OD_FIX | 0xff, OD_FIX_543 | OD_MODRM | 0x18, OD_END } },

	{ "cbw", 0, { OD_FIX | 0x98, OD_END } },
	{ "cdq", 0, { OD_FIX | 0x99, OD_END } },
	{ "clc", 0, { OD_FIX | 0xf8, OD_END } },
	{ "cld", 0, { OD_FIX | 0xfc, OD_END } },
	{ "cli", 0, { OD_FIX | 0xfa, OD_END } },
	{ "clts", 0, { OD_FIX | 0x0f, OD_FIX | 0x06, OD_END } },
	{ "cmc", 0, { OD_FIX | 0xf5, OD_END } },

	{ "cmov", OD_WIDTH_WIDE | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_4 | OD_TTTN | 0x40, OD_MODREGRM, OD_END } },

	{ "cmp", 0, { OD_FIX_6 | OD_D | OD_W | 0x38, OD_MODREGRM, OD_END } },
	{ "cmp", OD_IMM, { OD_FIX_6 | OD_S | OD_W | 0x80,
		OD_MODRM | OD_FIX_543 | 0x38, OD_END } },
	{ "cmp", OD_IMM | OD_REG_HARD_EAX, { OD_FIX_7 | OD_W | 0x3c, OD_END } },

	{ "cmps", 0, { OD_FIX_7 | OD_W | 0xa6, OD_END } },
	{ "cmpxchg", 0, { OD_FIX | 0x0f, OD_FIX_7 | OD_W | 0xb0, OD_MODREGRM,
		OD_END } },
	{ "cmpxchg8b", OD_WIDTH_DWIDE,
		{ OD_FIX | 0x0f, OD_FIX | 0xc7, OD_MODRM, OD_END } },

	{ "cpuid", 0, { OD_FIX | 0x0f, OD_FIX | 0xa2, OD_END } },
	/* cwd == cdq, cwde == cbw */
	{ "daa", 0, { OD_FIX | 0x27, OD_END } },
	{ "das", 0, { OD_FIX | 0x2f, OD_END } },
	{ "dec", 0, { OD_FIX_7 | OD_W | 0xfe, OD_FIX_543 | OD_MODRM | 0x08,
		OD_END } },
	{ "dec", OD_WIDTH_WIDE, { OD_FIX_5 | OD_LREG | 0x48, OD_END } },
	{ "div", 0, { OD_FIX_7 | OD_W | 0xf6, OD_FIX_543 | OD_MODRM | 0x30,
		OD_END } },
	{ "enter", OD_IMM | OD_IMMSIZE_8 | OD_IMM_DISPL | OD_IMM_DISPL_16,
		{ OD_FIX | 0xc8, OD_END } },
	{ "hlt", 0, { OD_FIX | 0xf4, OD_END } },
	{ "idiv", 0, { OD_FIX_7 | OD_W | 0xf6, OD_FIX_543 | OD_MODRM | 0x38,
		OD_END } },

	{ "imul", 0, { OD_FIX_7 | OD_W | 0xf6,
		OD_FIX_543 | OD_MODRM | 0x28, OD_END } },
	{ "imul", OD_REG12_REV | OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0xaf,
		OD_MODREGRM, OD_END } },
	{ "imul", OD_REG12_REV | OD_WIDTH_WIDE | OD_IMM | OD_IMMSIZE_WORD,
		{ OD_FIX_68 | OD_S | 0x69, OD_MODREGRM, OD_END } },

	{ "in", OD_WTONLY | OD_REG_HARD_EAX | OD_IMM | OD_IMMSIZE_8,
		{ OD_FIX_7 | OD_W | 0xe4, OD_END } },
	{ "in", OD_REG_HARD_EAX, { OD_FIX_7 | OD_W | 0xec, OD_END } },

	{ "inc", 0, { OD_FIX_7 | OD_W | 0xfe, OD_FIX_543 | OD_MODRM | 0x00,
		OD_END } },
	{ "inc", OD_WIDTH_WIDE, { OD_FIX_5 | OD_LREG | 0x40, OD_END } },
	{ "ins", 0, { OD_FIX_7 | OD_W | 0x6c, OD_END } },
	{ "int", OD_IMM | OD_IMMSIZE_8, { OD_FIX | 0xcd, OD_END } },
	{ "int3", 0, { OD_FIX | 0xcc, OD_END } },
	{ "into", 0, { OD_FIX | 0xce, OD_END } },
	{ "invd", 0, { OD_FIX | 0x0f, OD_FIX | 0x08, OD_END } },
	{ "invlpg", 0, { OD_FIX | 0x0f, OD_FIX | 0x01,
		OD_FIX_543 | OD_MODRM | 0x38, OD_END } },
	{ "iret", 0, { OD_FIX | 0xcf, OD_END } },

	{ "j", OD_JUMP | OD_IMM_DISPL | OD_IMM_DISPL_8,
		{ OD_FIX_4 | OD_TTTN | 0x70, OD_END } },
	{ "j", OD_JUMP | OD_IMM_DISPL | OD_IMM_DISPL_WORD,
		{ OD_FIX | 0x0f, OD_FIX_4 | OD_TTTN | 0x80, OD_END } },
	{ "jcxz", OD_JUMP | OD_IMM_DISPL | OD_IMM_DISPL_8,
		{ OD_FIX | 0xe3, OD_END } },
	{ "jmp", OD_JUMP | OD_IMM_DISPL | OD_IMM_DISPL_8,
		{ OD_FIX | 0xeb, OD_END } },
	{ "jmp", OD_JUMP | OD_IMM_DISPL | OD_IMM_DISPL_WORD,
		{ OD_FIX | 0xe9, OD_END } },
	{ "jmp", OD_JUMP | OD_WIDTH_WIDE, { OD_FIX | 0xff,
		OD_FIX_543 | OD_MODRM | 0x20, OD_END } },
	{ "jmp", OD_JUMP | OD_IMM_OFFSET | OD_IMMSIZE_WORD | OD_IMM_SELECT,
		{ OD_FIX | 0xea, OD_END } },
	{ "jmp", OD_JUMP | OD_WIDTH_WIDE, { OD_FIX | 0xff,
		OD_FIX_543 | OD_MODRM | 0x28, OD_END } },

	{ "lahf", 0, { OD_FIX | 0x9f, OD_END } },
	{ "lar", OD_REG12_REV | OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x02,
		OD_MODREGRM, OD_END } },
	{ "lds", 0, { OD_FIX | 0xc5, OD_MODREGRM, OD_END } },
	/* FIXME: OD_REG12_REV is odd for lea, check why */
	{ "lea", OD_REG12_REV | OD_WIDTH_WIDE,
		{ OD_FIX | 0x8d, OD_MODREGRM, OD_END } },
	{ "leave", 0, { OD_FIX | 0xc9, OD_END } },
	{ "les", 0, { OD_FIX | 0xc4, OD_MODREGRM, OD_END } },
	{ "lfs", 0, { OD_FIX | 0x0f, OD_FIX | 0xb4, OD_MODREGRM, OD_END } },
	{ "lgdt", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x01,
		OD_FIX_543 | OD_MODRM | 0x10, OD_END } },
	{ "lgs", 0, { OD_FIX | 0x0f, OD_FIX | 0xb5, OD_MODREGRM, OD_END } },
	{ "lldt", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x00,
		OD_FIX_543 | OD_MODRM | 0x10, OD_END } },
	{ "lmsw", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x01,
		OD_FIX_543 | OD_MODRM | 0x30, OD_END } },
	/* lock is a prefix */
	{ "lods", 0, { OD_FIX_7 | OD_W | 0xac, OD_END } },
	{ "loop", OD_IMM_DISPL | OD_IMM_DISPL_8, { OD_FIX | 0xe2, OD_END } },
	{ "loopz", OD_IMM_DISPL | OD_IMM_DISPL_8, { OD_FIX | 0xe1, OD_END } },
	{ "loopnz", OD_IMM_DISPL | OD_IMM_DISPL_8, { OD_FIX | 0xe0, OD_END } },

	{ "lsl", OD_REG12_REV | OD_WIDTH_WIDE,
		{ OD_FIX | 0x0f, OD_FIX | 0x03, OD_MODREGRM, OD_END } },
	{ "lss", 0, { OD_FIX | 0x0f, OD_FIX | 0xb2, OD_MODREGRM, OD_END } },
	{ "ltr", 0, { OD_FIX | 0x0f, OD_FIX | 0x00,
		OD_FIX_543 | OD_MODRM | 0x18, OD_END } },
	{ "mov", 0, { OD_FIX_6 | OD_D | OD_W | 0x88, OD_MODREGRM, OD_END } },
	{ "mov", OD_IMM, { OD_FIX_7 | OD_W | 0xc6,
		OD_FIX_543 | OD_MODRM | 0x00, OD_END } },
	{ "mov", OD_IMM, { OD_FIX_4 | OD_W3 | OD_LREG | 0xb0, OD_END } },
	{ "mov", OD_REG_HARD_EAX | OD_IMM_DISPL | OD_IMM_DISPL_WORD,
		{ OD_FIX_6 | OD_D | OD_W | 0xa0, OD_END } },

	{ "mov", OD_WIDTH_WIDE | OD_CR, { OD_FIX | 0x0f,
		OD_FIX_68 | OD_D | 0x20, OD_FIX_2 | OD_EEE | OD_LREG | 0xc0,
		OD_END } },
	{ "mov", OD_WIDTH_WIDE | OD_DR, { OD_FIX | 0x0f,
		OD_FIX_68 | OD_D | 0x21, OD_FIX_2 | OD_EEE | OD_LREG | 0xc0,
		OD_END } },
	{ "mov", OD_WIDTH_LOCK,
		{ OD_FIX_68 | OD_D | 0x8c, OD_SREG3 | OD_MODREGRM, OD_END } },

	{ "movs", 0, { OD_FIX_7 | OD_W | 0xa4, OD_END } },
	{ "movsx", OD_REG12_REV | OD_WIDTH_LWIDE, { OD_FIX | 0x0f,
		OD_FIX_7 | OD_W | 0xbe, OD_MODREGRM, OD_END } },
	{ "movzx", OD_REG12_REV | OD_WIDTH_LWIDE, { OD_FIX | 0x0f,
		OD_FIX_7 | OD_W | 0xb6, OD_MODREGRM, OD_END } },
	{ "mul", 0, { OD_FIX_7 | OD_W | 0xf6,
		OD_FIX_543 | OD_MODRM | 0x20, OD_END } },
	{ "neg", 0, { OD_FIX_7 | OD_W | 0xf6,
		OD_FIX_543 | OD_MODRM | 0x18, OD_END } },
	{ "nop", 0, { OD_FIX | 0x90, OD_END } },
	{ "not", 0, { OD_FIX_7 | OD_W | 0xf6,
		OD_FIX_543 | OD_MODRM | 0x10, OD_END } },
	{ "or", 0, { OD_FIX_6 | OD_D | OD_W | 0x08, OD_MODREGRM, OD_END } },
	{ "or", OD_IMM | OD_REG_HARD_EAX,
		{ OD_FIX_7 | OD_W | 0x0c, OD_END } },
	{ "or", OD_IMM, { OD_FIX_6 | OD_S | OD_W | 0x80,
		OD_FIX_543 | OD_MODRM | 0x08, OD_END } },
	{ "out", OD_REG12_REV | OD_WTONLY | OD_REG_HARD_EAX | OD_IMM | OD_IMMSIZE_8,
		{ OD_FIX_7 | OD_W | 0xe6, OD_END } },
	{ "out", OD_REG_HARD_EAX, { OD_FIX_7 | OD_W | 0xee, OD_END } },
	{ "outs", 0, { OD_FIX_7 | OD_W | 0x6e, OD_END } },

	{ "pop", OD_WIDTH_WIDE, { OD_FIX | 0x8f,
		OD_FIX_543 | OD_MODRM | 0x00, OD_END } },
	{ "pop", OD_WIDTH_WIDE, { OD_FIX_5 | OD_LREG | 0x58, OD_END } },

	/* XXX: this is broken in the intel documentation, where "pop cs" would
	 * result in a "0x0f" opcode, which is a extend-opcode. we work around
	 * this bug in the documentation(?) by splitting the opcode into its
	 * pieces: 000s.s111, s are the sreg bits. so we go for two choices:
	 * mask: 1111.0111 => 0001.0111,
	 * mask: 1110.1111 => 0000.0111,
	 * mask: 1111.1111 => 0001.1111,
	 * ignored:        => 0000.1111, as this would be 0x0f (extend-opcode)
	 *
	 * if the intel documentation would be correct, this line would
	 * suffice:
	 * { "pop", OD_WIDTH_LOCK, { OD_CMASK_SET(0xe7) | OD_SREG2 | 0x07,
	 *	OD_END } },
	 */
	{ "pop", OD_WIDTH_LOCK, { OD_CMASK_SET(0xf7) | OD_SREG2 | 0x17,
		OD_END } },
	{ "pop", OD_WIDTH_LOCK, { OD_CMASK_SET(0xef) | OD_SREG2 | 0x07,
		OD_END } },
	{ "pop", OD_WIDTH_LOCK, { OD_CMASK_SET(0xff) | OD_SREG2 | 0x1f,
		OD_END } },

	{ "pop", OD_WIDTH_LOCK, { OD_FIX | 0x0f,
		OD_CMASK_SET(0xc7) | OD_SREG3 | 0x81, OD_END } },
	{ "popa", 0, { OD_FIX | 0x61, OD_END } },
	{ "popf", 0, { OD_FIX | 0x9d, OD_END } },
	{ "push", OD_WIDTH_WIDE, { OD_FIX | 0xff,
		OD_FIX_543 | OD_MODRM | 0x30, OD_END } },
	{ "push", OD_WIDTH_WIDE, { OD_FIX_5 | OD_LREG | 0x50, OD_END } },

	{ "push", OD_IMM | OD_IMMSIZE_WORD, { OD_FIX | 0x68, OD_END } },
	{ "push", OD_IMM | OD_IMMSIZE_8, { OD_FIX | 0x6a, OD_END } },
	{ "push", OD_WIDTH_LOCK, { OD_CMASK_SET(0xe7) | OD_SREG2 | 0x06,
		OD_END } },
	{ "push", OD_WIDTH_LOCK, { OD_FIX | 0x0f,
		OD_CMASK_SET(0xc7) | OD_SREG3 | 0x80, OD_END } },
	{ "pusha", 0, { OD_FIX | 0x60, OD_END } },
	{ "pushf", 0, { OD_FIX | 0x9c, OD_END } },
	{ "rcl(1)", 0, { OD_FIX_7 | OD_W | 0xd0, OD_FIX_543 | OD_MODRM | 0x10,
		OD_END } },
	{ "rcl(cl)", 0, { OD_FIX_7 | OD_W | 0xd2,
		OD_FIX_543 | OD_MODRM | 0x10, OD_END } },
	{ "rcl", OD_IMM | OD_IMMSIZE_8, { OD_FIX_7 | OD_W | 0xc0,
		OD_FIX_543 | OD_MODRM | 0x10, OD_END } },
	{ "rcr(1)", 0, { OD_FIX_7 | OD_W | 0xd0, OD_FIX_543 | OD_MODRM | 0x18,
		OD_END } },
	{ "rcr(cl)", 0, { OD_FIX_7 | OD_W | 0xd2,
		OD_FIX_543 | OD_MODRM | 0x18, OD_END } },
	{ "rcr", OD_IMM | OD_IMMSIZE_8, { OD_FIX_7 | OD_W | 0xc0,
		OD_FIX_543 | OD_MODRM | 0x18, OD_END } },
	{ "rdmsr", 0, { OD_FIX | 0x0f, OD_FIX | 0x32, OD_END } },
	{ "rdpmc", 0, { OD_FIX | 0x0f, OD_FIX | 0x33, OD_END } },
	{ "rdtsc", 0, { OD_FIX | 0x0f, OD_FIX | 0x31, OD_END } },

	{ "ret", 0, { OD_FIX | 0xc3, OD_END } },
	{ "ret", OD_IMM_DISPL | OD_IMM_DISPL_16, { OD_FIX | 0xc2, OD_END } },
	{ "rol(1)", 0, { OD_FIX_7 | OD_W | 0xd0, OD_FIX_543 | OD_MODRM | 0x00,
		OD_END } },
	{ "rol(cl)", 0, { OD_FIX_7 | OD_W | 0xd2,
		OD_FIX_543 | OD_MODRM | 0x00, OD_END } },
	{ "rol", OD_IMM | OD_IMMSIZE_8, { OD_FIX_7 | OD_W | 0xc0,
		OD_FIX_543 | OD_MODRM | 0x00, OD_END } },
	{ "ror(1)", 0, { OD_FIX_7 | OD_W | 0xd0, OD_FIX_543 | OD_MODRM | 0x08,
		OD_END } },
	{ "ror(cl)", 0, { OD_FIX_7 | OD_W | 0xd2,
		OD_FIX_543 | OD_MODRM | 0x08, OD_END } },
	{ "ror", OD_IMM | OD_IMMSIZE_8, { OD_FIX_7 | OD_W | 0xc0,
		OD_FIX_543 | OD_MODRM | 0x08, OD_END } },
	{ "rsm", 0, { OD_FIX | 0x0f, OD_FIX | 0xaa, OD_END } },
	{ "sahf", 0, { OD_FIX | 0x9e, OD_END } },
	/* sal = shl */
	{ "sar(1)", 0, { OD_FIX_7 | OD_W | 0xd0, OD_FIX_543 | OD_MODRM | 0x38,
		OD_END } },
	{ "sar(cl)", 0, { OD_FIX_7 | OD_W | 0xd2,
		OD_FIX_543 | OD_MODRM | 0x38, OD_END } },
	{ "sar", OD_IMM | OD_IMMSIZE_8, { OD_FIX_7 | OD_W | 0xc0,
		OD_FIX_543 | OD_MODRM | 0x38, OD_END } },
	{ "sbb", 0, { OD_FIX_6 | OD_D | OD_W | 0x18, OD_MODREGRM, OD_END } },
	{ "sbb", OD_IMM | OD_REG_HARD_EAX,
		{ OD_FIX_7 | OD_W | 0x1c, OD_END } },
	{ "sbb", OD_IMM, { OD_FIX_6 | OD_S | OD_W | 0x80,
		OD_FIX_543 | OD_MODRM | 0x18, OD_END } },
	/* XXX: intel docs are plain wrong about this, they put scas as
	 *      1101.111w, while it is 1010.111w infact. doh! */
	{ "scas", 0, { OD_FIX_7 | OD_W | 0xae, OD_END } },
	{ "set", 0, { OD_FIX | 0x0f, OD_FIX_4 | OD_TTTN | 0x90,
		OD_FIX_543 | OD_MODRM | 0x00, OD_END } },
	{ "sgdt", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x01,
		OD_FIX_543 | OD_MODRM | 0x00, OD_END } },
	{ "shl(1)", 0, { OD_FIX_7 | OD_W | 0xd0, OD_FIX_543 | OD_MODRM | 0x20,
		OD_END } },
	{ "shl(cl)", 0, { OD_FIX_7 | OD_W | 0xd2,
		OD_FIX_543 | OD_MODRM | 0x20, OD_END } },
	{ "shl", OD_IMM | OD_IMMSIZE_8, { OD_FIX_7 | OD_W | 0xc0,
		OD_FIX_543 | OD_MODRM | 0x20, OD_END } },
	{ "shld", OD_IMM | OD_IMMSIZE_8 | OD_WIDTH_WIDE,
		{ OD_FIX | 0x0f, OD_FIX | 0xa4, OD_MODREGRM, OD_END } },
	{ "shld(cl)", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0xa5,
		OD_MODREGRM, OD_END } },
	{ "shr(1)", 0, { OD_FIX_7 | OD_W | 0xd0, OD_FIX_543 | OD_MODRM | 0x28,
		OD_END } },
	{ "shr(cl)", 0, { OD_FIX_7 | OD_W | 0xd2,
		OD_FIX_543 | OD_MODRM | 0x28, OD_END } },
	{ "shr", OD_IMM | OD_IMMSIZE_8, { OD_FIX_7 | OD_W | 0xc0,
		OD_FIX_543 | OD_MODRM | 0x28, OD_END } },
	{ "shrd", OD_IMM | OD_IMMSIZE_8 | OD_WIDTH_WIDE,
		{ OD_FIX | 0x0f, OD_FIX | 0xac, OD_MODREGRM, OD_END } },
	{ "shrd(cl)", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0xad,
		OD_MODREGRM, OD_END } },
	{ "sidt", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x01,
		OD_FIX_543 | OD_MODRM | 0x08, OD_END } },
	{ "sldt", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x00,
		OD_FIX_543 | OD_MODRM | 0x00, OD_END } },
	{ "smsw", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x01,
		OD_FIX_543 | OD_MODRM | 0x20, OD_END } },
	{ "stc", 0, { OD_FIX | 0xf9, OD_END } },
	{ "std", 0, { OD_FIX | 0xfd, OD_END } },
	{ "sti", 0, { OD_FIX | 0xfb, OD_END } },
	{ "stos", 0, { OD_FIX_7 | OD_W | 0xaa, OD_END } },
	{ "str", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x00,
		OD_FIX_543 | OD_MODRM | 0x08, OD_END } },
	{ "sub", 0, { OD_FIX_6 | OD_D | OD_W | 0x28, OD_MODREGRM, OD_END } },
	{ "sub", OD_IMM | OD_REG_HARD_EAX,
		{ OD_FIX_7 | OD_W | 0x2c, OD_END } },
	{ "sub", OD_IMM, { OD_FIX_6 | OD_S | OD_W | 0x80,
		OD_FIX_543 | OD_MODRM | 0x28, OD_END } },

	{ "test", 0, { OD_FIX_7 | OD_W | 0x84, OD_MODREGRM, OD_END } },
	{ "test", OD_IMM | OD_REG_HARD_EAX,
		{ OD_FIX_7 | OD_W | 0xa8, OD_END } },
	{ "test", OD_IMM | OD_IMMSIZE_WORD, { OD_FIX_7 | OD_W | 0xf6,
		OD_FIX_543 | OD_MODRM | 0x00, OD_END } },
	{ "ud2", 0, { OD_FIX | 0x0f, OD_FIX | 0x0b, OD_END } },
	{ "verr", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x00,
		OD_FIX_543 | OD_MODRM | 0x20, OD_END } },
	{ "verw", OD_WIDTH_WIDE, { OD_FIX | 0x0f, OD_FIX | 0x00,
		OD_FIX_543 | OD_MODRM | 0x28, OD_END } },
	{ "wait", 0, { OD_FIX | 0x9b, OD_END } },
	{ "wbinvd", 0, { OD_FIX | 0x0f, OD_FIX | 0x09, OD_END } },
	{ "wrmsr", 0, { OD_FIX | 0x0f, OD_FIX | 0x30, OD_END } },
	{ "xadd", 0, { OD_FIX | 0x0f, OD_FIX_7 | OD_W | 0xc0,
		OD_MODREGRM, OD_END } },
	{ "xchg", 0, { OD_FIX_7 | OD_W | 0x86, OD_MODREGRM, OD_END } },
	{ "xchg", OD_REG_HARD_EAX | OD_WIDTH_WIDE,
		{ OD_FIX_5 | OD_LREG | 0x90, OD_END } },
	{ "xlat", 0, { OD_FIX | 0xd7, OD_END } },

	{ "xor", 0, { OD_FIX_6 | OD_D | OD_W | 0x30, OD_MODREGRM, OD_END } },
	{ "xor", OD_IMM | OD_REG_HARD_EAX,
		{ OD_FIX_7 | OD_W | 0x34, OD_END } },
	{ "xor", OD_IMM , { OD_FIX_6 | OD_S | OD_W | 0x80,
		OD_FIX_543 | OD_MODRM | 0x30, OD_END } },

	/*** MMX
	 */
	{ "emms", OD_MMX, { OD_FIX | 0x0f, OD_FIX | 0x77, OD_END } },
	{ "movd", OD_MMX | OD_GG_D | OD_REGNOMMX | OD_REG12_REV,
		{ OD_FIX | 0x0f, OD_FIX | 0x6e, OD_MODREGRM, OD_END } },
	{ "movd", OD_MMX | OD_GG_D | OD_WIDTH_WIDE | OD_REGNOMMX,
		{ OD_FIX | 0x0f, OD_FIX | 0x7e, OD_MODREGRM, OD_END } },
	{ "movq", OD_WIDTH_LOCK | OD_MMX | OD_GG_Q | OD_REG12_REV,
		{ OD_FIX | 0x0f, OD_FIX | 0x6f, OD_MODREGRM, OD_END } },
	{ "movq", OD_WIDTH_LOCK | OD_MMX | OD_GG_Q, { OD_FIX | 0x0f,
		OD_FIX | 0x7f, OD_MODREGRM, OD_END } },
	{ "packssdw", OD_MMX | OD_GG_D | OD_GG_IN_HI | OD_REG12_REV,
		{ OD_FIX | 0x0f, OD_FIX | 0x6b, OD_MODREGRM, OD_END } },
	{ "packsswb", OD_MMX | OD_GG_W | OD_GG_IN_HI | OD_REG12_REV,
		{ OD_FIX | 0x0f, OD_FIX | 0x63, OD_MODREGRM, OD_END } },
	{ "packuswb", OD_MMX | OD_GG_W | OD_GG_IN_HI | OD_REG12_REV,
		{ OD_FIX | 0x0f, OD_FIX | 0x67, OD_MODREGRM, OD_END } },
	{ "padd", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0xfc, OD_MODREGRM, OD_END } },
	{ "padds", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0xec, OD_MODREGRM, OD_END } },
	{ "paddus", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0xdc, OD_MODREGRM, OD_END } },
	{ "pand", OD_MMX | OD_GG_Q | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX | 0xdb, OD_MODREGRM, OD_END } },
	{ "pandn", OD_MMX | OD_GG_Q | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX | 0xdf, OD_MODREGRM, OD_END } },
	{ "pcmpeq", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0x74, OD_MODREGRM, OD_END } },
	{ "pcmpgt", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0x64, OD_MODREGRM, OD_END } },
	{ "pmadd", OD_MMX | OD_GG_W | OD_GG_IN_LOW | OD_REG12_REV,
		{ OD_FIX | 0x0f, OD_FIX | 0xf5, OD_MODREGRM, OD_END } },
	{ "pmulh", OD_MMX | OD_GG_W | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX | 0xe5, OD_MODREGRM, OD_END } },
	{ "pmull", OD_MMX | OD_GG_W | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX | 0xd5, OD_MODREGRM, OD_END } },
	{ "por", OD_MMX | OD_GG_Q | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX | 0xeb, OD_MODREGRM, OD_END } },
	{ "psll", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0xf0, OD_MODREGRM, OD_END } },
	{ "psll", OD_MMX | OD_IMM | OD_IMMSIZE_8, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0x70, OD_FIX_5 | OD_LREG | 0xf0, OD_END } },
	{ "psra", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0xe0, OD_MODREGRM, OD_END } },
	{ "psra", OD_MMX | OD_IMM | OD_IMMSIZE_8, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0x70, OD_FIX_5 | OD_LREG | 0xe0, OD_END } },
	{ "psrl", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0xd0, OD_MODREGRM, OD_END } },
	{ "psrl", OD_MMX | OD_IMM | OD_IMMSIZE_8, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0x70, OD_FIX_5 | OD_LREG | 0xd0, OD_END } },
	{ "psub", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0xf8, OD_MODREGRM, OD_END } },
	{ "psubs", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0xe8, OD_MODREGRM, OD_END } },
	{ "psubus", OD_MMX | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0xd8, OD_MODREGRM, OD_END } },
	{ "punpckh", OD_MMX | OD_GG_IN_LOW | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0x68, OD_MODREGRM, OD_END } },
	{ "punpckl", OD_MMX | OD_GG_IN_LOW | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX_6 | OD_GG | 0x60, OD_MODREGRM, OD_END } },
	{ "pxor", OD_MMX | OD_GG_Q | OD_REG12_REV, { OD_FIX | 0x0f,
		OD_FIX | 0xef, OD_MODREGRM, OD_END } },

	{ NULL, 0, { OD_END } },
};

unsigned int	ia32_opcode_tabsize =
	(sizeof (ia32_opcode_table) / sizeof (ia32_opcode_e)) - 1;


/*** local function prototypes
 */
static unsigned int
ia32_decode_value (unsigned char *input, unsigned int bits,
	unsigned int *value);

static void
ia32_decode_opcode_mod (unsigned char *input, unsigned int bp,
	ia32_opcode_e *oel, ia32_opcode *opc,
	unsigned int reg_width, unsigned int addr_width);

static ia32_opcode_e *
ia32_decode_opcode_find (unsigned char *input);

static void
ia32_decode_opcode_sib (unsigned char *input, unsigned int bp,
	ia32_opcode *opc);


/*** public functions
 */

ia32_instruction *
ia32_decode_instruction (unsigned char *input, ia32_instruction *new)
{
	int		new_malloc = 0;
	ia32_prefix *	pfx;
	ia32_opcode *	opc;


	if (new == NULL) {
		new = malloc (sizeof (ia32_instruction));
		new_malloc = 1;
	}
	memset (new, 0x00, sizeof (ia32_instruction));

	pfx = ia32_decode_prefix (input, &new->pfx);
	opc = ia32_decode_opcode (input + pfx->length, &new->opc, pfx);

	if (opc == NULL) {
		fprintf (stderr, "error, no opc structure found :(\n");
		if (new_malloc)
			free (new);

		return (NULL);
	}

	new->user = NULL;
	new->length = pfx->length + opc->length;

	return (new);
}


ia32_prefix *
ia32_decode_prefix (unsigned char *input, ia32_prefix *new)
{
	int		pw;
	ia32_prefix_e *	pewlk;


	if (new == NULL)
		new = malloc (sizeof (ia32_prefix));

	memset (new, 0x00, sizeof (ia32_prefix));

	for (pw = 0 ; pw < IA32_PREFIX_MAX ; ++pw) {
		for (pewlk = ia32_prefix_table ; pewlk->name != NULL ;
			++pewlk)
		{
			if (pewlk->code != input[pw])
				continue;

			if (pewlk->relact == RELACT_OVERRIDE)
				*PFX_ABS (new, pewlk->relptr) = pewlk->relval;
			else if (pewlk->relact == RELACT_COMBINE)
				*PFX_ABS (new, pewlk->relptr) |= pewlk->relval;

			new->prefix[pw] = pewlk;
			break;
		}

		if (pewlk->name == NULL)
			break;
	}

	new->prefix[pw] = NULL;
	new->length = pw;

	return (new);
}


ia32_opcode *
ia32_decode_opcode (unsigned char *input, ia32_opcode *new,
	ia32_prefix *pfx)
{
	int		bp;	/* byte pointer into opcode */
	int		mmx_gg = -1;
	int		sflag = 0;	/* has the s flag occured ? */
	ia32_opcode_e *	oel;

	/* helper variables for decoding
	 */
	int		wide = 0;
	/* FIXME: do this to runtime with a cpu state structure */
	int		wide_cur = 32,
			wide_addr_cur = 32;
	int		short_cur = 8;


	/* try to locate the appropiate decoding structure from the opcode
	 * table. if there is no matching one, bail out early.
	 */
	oel = ia32_decode_opcode_find (input);
	if (oel == NULL)
		return (NULL);

	if (new == NULL)
		new = malloc (sizeof (ia32_opcode));

	memset (new, 0x00, sizeof (ia32_opcode));
	new->opcode = oel;


	if (OD_TEST (oel->flags, OD_IMM)) {
		new->used |= OP_IMMEDIATE | OP_SOURCE;
		new->source_type = OP_TYPE_IMM;
	}

	if (OD_TEST (oel->flags, OD_JUMP))
		new->used |= OP_JUMP;

	/* when there are size prefixes, modify the operand and address size
	 * attributes. XXX: the intel docs make a huge difference as to whether
	 * operands or addressing is concerned, we share it in one flag (wide).
	 */
	if (pfx != NULL) {
		if (pfx->oper_size)
			wide_cur = 16;

		if (pfx->addr_size)
			wide_addr_cur = 16;
	}


	for (bp = 0 ; oel->opc[bp] != OD_END ; ++bp) {
		unsigned int	oc;
		unsigned char	ob;

		oc = oel->opc[bp];
		ob = input[bp];

		/* width flag (bit 0 or bit 3)
		 */
		if (OD_TEST (oc, OD_W))
			new->wide = wide = OD_SET_COND (ob, OD_W_MASK);
		else if (OD_TEST (oc, OD_W3))
			new->wide = wide = OD_SET_COND (ob, OD_W3_MASK);

		/* s sign-extension flag (bit 1)
		 */
		if (OD_TEST (oc, OD_S))
			sflag = OD_SET_COND (ob, OD_S_MASK);

		/* direction flag (bit 1)
		 */
		if (OD_TEST (oc, OD_D))
			new->reversed = OD_SET_COND (ob, OD_S_MASK);

		if (OD_TEST (oc, OD_GG))
			mmx_gg = ob & OD_GG_MASK;

		/* tttn condition codes (bits 3210)
		 */
		if (OD_TEST (oc, OD_TTTN)) {
			new->used |= OP_COND;
			new->cond = ob & OD_TTTN_MASK;
		}

		/* low register encoded (bits 210)
		 */
		if (OD_TEST (oc, OD_LREG)) {
			/* when there is another hardcoded register, assume
			 * this lreg to be the source, otherwise target
			 */
			if (OD_TEST (oel->flags, OD_REG_HARD_EAX)) {
				new->source_reg = ob & OD_LREG_MASK;
				new->source_type = OP_TYPE_REG;
				new->used |= OP_SOURCE;
				fprintf (stderr, "lreg to source\n");
			} else {
				new->target_reg = ob & OD_LREG_MASK;
				new->target_type = OP_TYPE_REG;
				new->used |= OP_TARGET;
			}
		}

		if (OD_TEST (oc, OD_EEE)) {
			new->source_reg = (ob & OD_EEE_MASK) >> 3;
			new->used |= OP_SOURCE;

			if (OD_TEST (oel->flags, OD_CR)) {
				new->source_type = OP_TYPE_SPEC_CR;
			} else if (OD_TEST (oel->flags, OD_DR)) {
				new->source_type = OP_TYPE_SPEC_DR;
			} else {
				fprintf (stderr, "no special eee type given.\n");
			}
		}

		/* modbyte encoding (bits 76, possible 543, possible 210)
		 */
		if (OD_TEST (oc, OD_MOD))
			ia32_decode_opcode_mod (input, bp, oel, new, wide_cur,
				wide_addr_cur);

		/* for sreg3 we use the mod decoding facility and later make
		 * up the register type. when we have a register-to-register
		 * move, sreg3 is always the target (or source, but then it
		 * will be reversed). for non-register transfers, it is the
		 * register-type. XXX: note, that any sreg3 instruction must
		 * have a OD_MOD at the same byte as the eee field for this
		 * to work.
		 */
		if (OD_TEST (oc, OD_SREG3) && OD_TEST (oc, OD_MOD)) {
			/* register to register */
			if ((ob & OD_MOD_MASK) == OD_MOD_MASK) {
				new->source_type = OP_TYPE_SPEC_SEG;
				new->source_width = 16;
				new->target_width = wide_cur;
			} else {
				if (new->target_type == OP_TYPE_REG) {
					new->target_type = OP_TYPE_SPEC_SEG;
				} else if (new->source_type == OP_TYPE_REG) {
					new->source_type = OP_TYPE_SPEC_SEG;
				}
				new->source_width = new->target_width =
					IA32_SEG_SIZE;
			}
		/* second case, for more simpler instructions, such as push
		 * and pop, which do not make use of modbytes.
		 */
		} else if (OD_TEST (oc, OD_SREG3) || OD_TEST (oc, OD_SREG2)) {
			new->used |= OP_TARGET;
			new->target_width = IA32_SEG_SIZE;
			new->target_type = OP_TYPE_SPEC_SEG;

			new->target_reg = (ob & (OD_TEST (oc, OD_SREG3) ?
				OD_SREG3_MASK : OD_SREG2_MASK)) >> 3;
		}
	}

	if (OD_TEST (oel->flags, OD_REG_HARD_EAX)) {
		new->target_type = OP_TYPE_REG;
		new->target_reg = IA32_REG_EAX;
		new->used |= OP_TARGET;
	}

	/* fix width of operands
	 */
	if (OD_TEST (oel->flags, OD_WIDTH_LOCK) == 0) {
		new->source_width = new->target_width = short_cur;

		if (OD_TEST (oel->flags, OD_WIDTH_WIDE) || wide == 1) {
			new->target_width = wide_cur;

			if (sflag == 0 && OD_TEST (oel->flags, OD_WTONLY) == 0)
				new->source_width = wide_cur;
		}
	}

	if (OD_TEST (oel->flags, OD_MMX)) {
		/* gg field encoding
		 */
		unsigned int	mmx_sizes[] = { 8, 16, 32, 64 };
		unsigned int	mmx_length;


		/* get length depending on the instruction format:
		 *
		 * 1. if there is a gg field, decode length
		 * 2. else fetch from instruction
		 */
		if (mmx_gg == -1)
			mmx_length = mmx_sizes[OD_GG_GET (oel->flags)];
		else
			mmx_length = mmx_sizes[mmx_gg];

		printf ("\tmmx_length = %d, mmx_gg = %d, OD_GG_GET (oel->flags) = %d\n",
			mmx_length, mmx_gg, OD_GG_GET (oel->flags));

		new->target_width = mmx_length;

		if (new->target_type == OP_TYPE_REG &&
			OD_TEST (oel->flags, OD_REGNOMMX) == 0)
		{
			new->target_type = OP_TYPE_SPEC_MMX;
		}
#if 0
		if (new->target_type == OP_TYPE_REG &&
			OD_TEST (oel->flags, OD_REGNOMMX) == 0)
		{
			new->target_width = mmx_length;
			new->target_type = OP_TYPE_SPEC_MMX;
		}
#endif

		new->source_width = mmx_length;

		if (new->source_type == OP_TYPE_REG)
			new->source_type = OP_TYPE_SPEC_MMX;

		if (OD_TEST (oel->flags, OD_GG_IN_LOW))
			new->source_width = 2 * new->target_width;
		if (OD_TEST (oel->flags, OD_GG_IN_HI))
			new->source_width = new->target_width / 2;
	}

	/* edx:eax combinations
	 */
	if (OD_TEST (oel->flags, OD_WIDTH_DWIDE))
		new->target_width = 2 * wide_cur;

	/* decode the SIB byte (which can result in displacement modification)
	 */
	if (OD_TEST (new->used, OP_SIB)) {
		ia32_decode_opcode_sib (input, bp, new);
		bp += 1;
	}

	/* decode possible displacement after mod r/m or SIB byte
	 * in case this is a immediate-target instruction (jump, call, ..)
	 * instruct the displacement properly. also appears as explicit 16 bit
	 * displacement in the enter instruction. also decode selectors.
	 */
	if (OD_TEST (oel->flags, OD_IMM_DISPL)) {
		new->used |= OP_DISPLACE;

		if (OD_TEST (oel->flags, OD_IMM_DISPL_8)) {
			new->displ_size = 8;
		} else if (OD_TEST (oel->flags, OD_IMM_DISPL_16)) {
			new->displ_size = 16;
		} else if (OD_TEST (oel->flags, OD_IMM_DISPL_WORD)) {
			new->displ_size = wide_cur;
		}

		/* an immediate displacement has to belong either to the
		 * source or destination operand
		 */
		if (OD_TEST (new->used, OP_TARGET) == 0) {
			new->used |= OP_TARGET;
			new->target_type = OP_TYPE_DISPL;
			new->target_width = new->displ_size;
		} else {
			new->used |= OP_SOURCE;
			new->source_type = OP_TYPE_MEM;
			new->source_width = new->displ_size;
		}
	}

	if (OD_TEST (new->used, OP_DISPLACE)) {
		new->displ_value = 0;
		bp += ia32_decode_value (&input[bp], new->displ_size,
			&new->displ_value);
	}

	/* immediate selector and offsets
	 */
	if (OD_TEST (oel->flags, OD_IMM_OFFSET)) {
		new->used |= OP_TARGET;
		new->target_type = OP_TYPE_OFFSET;
		new->target_width = new->imm_size = wide_cur;
		bp += ia32_decode_value (&input[bp], new->imm_size,
			&new->imm_value);
	}

	if (OD_TEST (oel->flags, OD_IMM_SELECT)) {
		unsigned int	selector;

		new->used |= OP_TARGET | OP_SELECTOR;
		bp += ia32_decode_value (&input[bp], 16, &selector);
		new->selector = (unsigned short) selector;
	}

	if (OD_TEST (new->used, OP_IMMEDIATE)) {
		new->imm_value = 0;

		if (OD_TEST (oel->flags, OD_IMMSIZE_WORD)) {
			new->imm_size = wide_cur;
		} else {
			switch (OD_IMMSIZE_GET (oel->flags)) {
			case (OD_IMMSIZE_8):
				new->imm_size = 8;
				break;
			case (OD_IMMSIZE_16):
				new->imm_size = 16;
				break;
			case (OD_IMMSIZE_32):
				new->imm_size = 32;
				break;
			default:
				new->imm_size = new->source_width;
				fprintf (stderr, "imm_size from source: %d\n",
					new->imm_size);
				break;
			}
		}

		bp += ia32_decode_value (&input[bp], new->imm_size,
			&new->imm_value);
	}
	new->length = bp;

	/* XXX: there are cases (such as the bsf and bsr instructions, where
	 * the order of registers is reversed by default. in that case, flip)
	 */
	if (OD_TEST (oel->flags, OD_REG12_REV))
		new->reversed = (new->reversed == 0) ? 1 : 0;

	/* when the order was reversed, then swap source and target now.
	 * let reversed bit stick, though, since source_* is always source,
	 * and target_* always target (to the user of this function). so
	 * we provide the extra information about the original encoding through
	 * the reversed bit.
	 */
	if (new->reversed) {
#define	swapui32(x,y) (x)^=(y);(y)^=(x);(x)^=(y);
		swapui32 (new->source_type, new->target_type);
		swapui32 (new->source_reg, new->target_reg);
		swapui32 (new->source_width, new->target_width);
#undef swapui32
	}

	if (OD_TEST (oel->flags, OD_WIDTH_LWIDE))
		new->target_width = wide_cur;

	return (new);
}


/*** private functions
 */

/* ia32_decode_value
 *
 * decode immediate data at `input' into a host-independant integer at `value'.
 * the data read from `input' is `bits' bits long. the only correct values are
 * 8, 16 or 32.
 *
 * return number of bytes processed
 */

static unsigned int
ia32_decode_value (unsigned char *input, unsigned int bits,
	unsigned int *value)
{
	switch (bits) {
	case (32):
		*value = input[0] | (input[1] << 8) | (input[2] << 16) |
			(input[3] << 24);
		return (4);
		break;
	case (16):
		*value = input[0] | (input[1] << 8);
		return (2);
		break;
	case (8):
		*value = input[0];
		return (1);
		break;
	default:
		return (0);
	}
}


/* ia32_decode_opcode_sib
 *
 * decode the SIB byte found at input[bp] into the opcode structure `opc'.
 *
 * return in any case
 */

static void
ia32_decode_opcode_sib (unsigned char *input, unsigned int bp,
	ia32_opcode *opc)
{
	unsigned char	sib = input[bp];


	opc->sibbyte = sib;
	opc->scale = (sib & 0xc0) >> 6;
	opc->index_reg = (sib & 0x38) >> 3;
	opc->base_reg = sib & 0x07;

	/* special case: no scaled index used (index = 0x04)
	 */
	if (opc->index_reg == 0x04) {
		opc->index = 0;
		opc->index_reg = 0;
	} else
		opc->index = 1;

	/* special case: mod was 00, sib base is 101 (ebp normally)
	 * then: no base used, but a disp32 (see, ia32 vol.2, pp 36-660)
	 */
	if (((opc->modbyte & 0xc0) >> 6) == 0x0 && opc->base_reg == 0x5) {
		opc->base = 0;
		opc->base_reg = 0;

		opc->used |= OP_DISPLACE;
		opc->displ_size = 32;
	} else
		opc->base = 1;

	return;
}


/* ia32_decode_opcode_mod
 *
 * decode the mod (possibly reg, possibly r/m) byte found at input[bp], with
 * the opcode structure `oel' into the decode structure `opc'
 *
 * return in any case
 */

static void
ia32_decode_opcode_mod (unsigned char *input, unsigned int bp,
	ia32_opcode_e *oel, ia32_opcode *opc,
	unsigned int reg_width, unsigned int addr_width)
{
	/* FIXME: assume 32 bit for now
	 * TODO: add a cpu-state structure, to support 32/16 bit decisions and
	 *       such
	 */
	unsigned char	modbyte = input[bp];
	unsigned int	mod;
	unsigned int	reg,
			rm = modbyte & OD_RM_MASK;
	unsigned int	oc = oel->opc[bp];


	opc->modbyte = modbyte;

	if (OD_TEST (oc, OD_REG)) {
		reg = (modbyte & OD_REG_MASK) >> 3;

		opc->used |= OP_SOURCE;
		opc->source_type = OP_TYPE_REG;
		opc->source_reg = reg;
		opc->source_width = reg_width;
	}

	mod = (modbyte & 0xc0) >> 6;
	/* mod = 11 = register to register */
	if (mod == 0x3) {
		opc->used |= OP_TARGET;
		opc->target_type = OP_TYPE_REG;
		opc->target_reg = rm;
		opc->target_width = reg_width;

		/* there is no sib */
		return;
	}

	/* 0, 8 or 32 bit displacements plus reg indirect, without SIB
	 */
	opc->used |= OP_TARGET;
	opc->target_type = OP_TYPE_MEMREG;
	opc->target_reg = rm;
	opc->target_width = addr_width;

	/* switch three addressing modes, disp0, disp8 and disp32
	 * displacement size equals address size
	 */
	switch (mod) {
	case (0x00):
		opc->displ_size = 0;

		if (rm == IA32_MOD00_RM_DIRECT) {
			opc->displ_size = addr_width;
			opc->used |= OP_DISPLACE;

			opc->target_type = OP_TYPE_MEMABS;
			opc->target_reg = 0;
		}

		break;
	case (0x01):
		opc->displ_size = 8;
		opc->used |= OP_DISPLACE;
		break;
	case (0x02):
		opc->displ_size = addr_width;
		opc->used |= OP_DISPLACE;
		break;
	}

	/* in case this is an SIB mod r/m byte, mark it as such
	 */
	if (rm == IA32_RM_SIB) {
		opc->used |= OP_SIB;
		opc->target_type = OP_TYPE_MEM;
		opc->target_reg = 0;
	}

	return;
}


/* ia32_decode_opcode_find
 *
 * try to find an appropiate opcode structure matching the opcode found at
 * `input'.
 *
 * return NULL on failure
 * return pointer to opcode description structure on success
 */

static ia32_opcode_e *
ia32_decode_opcode_find (unsigned char *input)
{
	unsigned int	n;
	ia32_opcode_e *	opcwlk;


	for (opcwlk = ia32_opcode_table ; opcwlk->name != NULL ; ++opcwlk) {
		for (n = 0 ; opcwlk->opc[n] != OD_END ; ++n) {
			if ((input[n] & OD_CMASK_GET (opcwlk->opc[n])) !=
				OD_CVAL_GET (opcwlk->opc[n]))
				break;
		}

		if (opcwlk->opc[n] == OD_END)
			return (opcwlk);
	}

	return (NULL);
}


/* print an opcode from decoded structure (just a quick hack)
 *
 * TODO: convert this into a more clean version with into-string support
 * TODO: make this an API function
 *
 * this function is a bit messy, but most of the mess is due to make "pretty"
 * output to the human eye. you can rip half of the stuff if you want a correct
 * machine readable string representation.
 */

void
ia32_print (ia32_instruction *inst)
{
	ia32_opcode *	opc = &inst->opc;

	int	used_immediate = 0;

	char *	regs_wide[] = { "eax", "ecx", "edx", "ebx",
		"esp", "ebp", "esi", "edi" };
	char *	regs_half[] = { "ax", "cx", "dx", "bx",
		"sp", "bp", "si", "di" };
	char *	regs_half_addr[] = { "bx + si", "bx + di", "bp + si",
		"bp + di", "si", "di", "disp16:FIXME", "bx" };
	char *	regs_small[] = { "al", "cl", "dl", "bl",
		"ah", "ch", "dh", "bh" };
	char *	regs_spec_cr[] = { "cr0", "cr_invalid", "cr2", "cr3", "cr4",
		"cr_invalid", "cr_invalid", "cr_invalid" };
	char *	regs_spec_dr[] = { "dr0", "dr1", "dr2", "dr3", "dr_invalid",
		"dr_invalid", "dr6", "dr7" };
	char *	regs_spec_seg[] = { "es", "cs", "ss", "ds", "fs", "gs",
		"seg_invalid", "seg_invalid" };
	char *	regs_spec_mmx[] = { "mm0", "mm1", "mm2", "mm3", "mm4",
		"mm5", "mm6", "mm7" };
	char **	regs = regs_wide;

	int	lidx[] = {	0,0,0,0,0,0,0,0,1,
				0,0,0,0,0,0,0,2,
				0,0,0,0,0,0,0,0,
				0,0,0,0,0,0,0,3 };
	char *	lstr[] = { "invalid", "byte", "word", "dword" };
	char **	ltab[] = { NULL, regs_small, regs_half, regs_wide };
	char *	scalestr[] = { "", "*2", "*4", "*8" };
	char *	condstr[] = { "o", "no", "b,nae", "nb,ae", "e,z", "ne,nz",
		"be,na", "nbe,a", "s", "ns", "p,pe", "np,po", "l,nge",
		"nl,ge", "le,ng", "nle,g" };


	printf ("\t%s", opc->opcode->name);
	if (OD_TEST (opc->used, OP_COND))
		printf ("(%s)", condstr[opc->cond]);

	/* when this is a no-operand instruction with a width flag, show this
	 */
	if (OD_TEST (opc->used, OP_TARGET) == 0 &&
		OD_TEST (opc->used, OP_SOURCE) == 0)
	{
		unsigned int	owlk;

		for (owlk = 0 ; opc->opcode->opc[owlk] != OD_END ; ++owlk) {
			if (OD_TEST (opc->opcode->opc[owlk], OD_W))
				printf ("(%s)", (opc->wide) ? "d" : "b");
		}
	}

	if (OD_TEST (opc->used, OP_TARGET)) {
		printf ("\t");

		if (opc->target_width != 64)
			regs = ltab[lidx[opc->target_width]];

		if (opc->target_type != OP_TYPE_REG &&
			opc->target_type != OP_TYPE_SPEC_CR &&
			opc->target_type != OP_TYPE_SPEC_DR &&
			opc->target_type != OP_TYPE_SPEC_SEG)
		{
			if (opc->target_width == 64)
				printf ("qword ");
			else
				printf ("%s ", lstr[lidx[opc->target_width]]);
		}

		if (OD_TEST (opc->used, OP_SELECTOR))
			printf ("0x%04hx:", opc->selector);

		/* now switch :)
		 */
		switch (opc->target_type) {
		case (OP_TYPE_SPEC_CR):
			printf ("%s", regs_spec_cr[opc->target_reg]);
			break;

		case (OP_TYPE_SPEC_DR):
			printf ("%s", regs_spec_dr[opc->target_reg]);
			break;

		case (OP_TYPE_SPEC_SEG):
			printf ("%s", regs_spec_seg[opc->target_reg]);
			break;

		case (OP_TYPE_SPEC_MMX):
			printf ("%s", regs_spec_mmx[opc->target_reg]);
			break;

		case (OP_TYPE_REG):
			printf ("%s", regs[opc->target_reg]);
			break;

		case (OP_TYPE_MEMABS):
			if (OD_TEST (opc->used, OP_DISPLACE)) {
				printf ("[0x%08x]", opc->displ_value);
			} else {
				printf ("error, OP_TYPE_MEMABS, no displ");
			}
			break;

		case (OP_TYPE_MEMREG):
			if (inst->pfx.addr_size)
				regs = regs_half_addr;
			else
				regs = regs_wide;

			printf ("[%s", regs[opc->target_reg]);
			if (OD_TEST (opc->used, OP_DISPLACE)) {
				printf (" + (%u)0x%08x]", opc->displ_size,
					opc->displ_value);
			} else
				printf ("]");
			break;

		case (OP_TYPE_MEM):
			printf ("[");
			if (opc->base)
				printf ("%s", regs[opc->base_reg]);

			if (opc->base && opc->index)
				printf (" + ");

			if (opc->index)
				printf ("%s%s", regs[opc->index_reg],
					scalestr[opc->scale]);
			if (OD_TEST (opc->used, OP_DISPLACE)) {
				printf ("%s(%u)0x%08x",
					(opc->index) ? " + " : "",
					opc->displ_size, opc->displ_value);
			}
			printf ("]");
			break;

		/* an immediate target means something special, such as a port
		 * number.
		 */
		case (OP_TYPE_IMM):
			printf ("(%u)0x%08x", opc->imm_size, opc->imm_value);
			used_immediate = 1;
			break;

		case (OP_TYPE_DISPL):
			printf ("(%u)0x%08x", opc->displ_size,
				opc->displ_value);
			break;

		case (OP_TYPE_OFFSET):
			printf ("0x%08x", opc->imm_value);
			used_immediate = 1;
			break;
		default:
			break;
		}
	}

	/* TODO: merge code that is used in both source and target
	 */
	if (OD_TEST (opc->used, OP_SOURCE)) {
		if (OD_TEST (opc->used, OP_TARGET))
			printf (", ");
		else
			printf ("\t");

		if (opc->target_width != 64)
			regs = ltab[lidx[opc->source_width]];

		if (opc->source_type == OP_TYPE_SPEC_CR) {
			printf ("%s", regs_spec_cr[opc->source_reg]);
		} else if (opc->source_type == OP_TYPE_SPEC_DR) {
			printf ("%s", regs_spec_dr[opc->source_reg]);
		} else if (opc->source_type == OP_TYPE_SPEC_SEG) {
			printf ("%s", regs_spec_seg[opc->source_reg]);
		} else if (opc->source_type == OP_TYPE_SPEC_MMX) {
			if (opc->source_width == 64) {
				printf ("qword ");
			} else
				printf ("%s ", lstr[lidx[opc->source_width]]);

			printf ("%s", regs_spec_mmx[opc->source_reg]);
		} else if (opc->source_type == OP_TYPE_REG) {
			printf ("%s", regs[opc->source_reg]);
		} else if (opc->source_type == OP_TYPE_IMM) {
			printf ("(%u)0x%08x", opc->imm_size, opc->imm_value);
			used_immediate = 1;
		} else {
			if (opc->source_width == 64) {
				printf ("qword ");
			} else {
				printf ("%s ", lstr[lidx[opc->source_width]]);
				regs = ltab[lidx[opc->source_width]];
			}
		}

		if (opc->source_type == OP_TYPE_MEMABS) {
			if (OD_TEST (opc->used, OP_DISPLACE)) {
				printf ("[0x%08x]", opc->displ_value);
			} else {
				printf ("error, OP_TYPE_MEMABS, no displ");
			}
		} else if (opc->source_type == OP_TYPE_MEMREG) {
			if (inst->pfx.addr_size)
				regs = regs_half_addr;
			else
				regs = regs_wide;

			printf ("[%s", regs[opc->source_reg]);
			if (OD_TEST (opc->used, OP_DISPLACE)) {
				printf (" + (%u)0x%08x]", opc->displ_size,
					opc->displ_value);
			} else
				printf ("]");

		} else if (opc->source_type == OP_TYPE_MEM) {
			printf ("[");
			if (opc->base)
				printf ("%s", regs[opc->base_reg]);

			if (opc->base && opc->index)
				printf (" + ");

			if (opc->index)
				printf ("%s%s", regs[opc->index_reg],
					scalestr[opc->scale]);

			if (OD_TEST (opc->used, OP_DISPLACE)) {
				printf ("%s(%u)0x%08x",
					(opc->index) ? " + " : "",
					opc->displ_size,
					opc->displ_value);
			}
			printf ("]");
		}
	}

	if (OD_TEST (opc->used, OP_IMMEDIATE) && used_immediate == 0)
		printf (", (%u)0x%08x", opc->imm_size, opc->imm_value);

	printf ("\n");
}

#ifdef TESTING


int
main (int argc, char *argv[])
{
	unsigned char *	tests[] = {
		"\x0f\x77",	/* emms */
		"\x0f\x6e\xc1",	/* movd	mm0, ecx */

		"\x66\x87\x1b",	/* xchg	word [ebx], bx */
		"\x67\x87\x1b",	/* xchg	dword [bx], ebx */
		"\x66\x67\x87\x1f",	/* xchg	word [bx], bx */
		"\x66\x67\x87\x18",	/* xchg	word [bx + si], bx */
		"\x67\x66\x87\x1b",	/* xchg	word [bp + di], bx */
		"\x67\x8b\x80\x02\x01",	/* mov     eax, dword [bx + si + 0x0102] */
		"\x67\x8b\x87\x02\x01",	/* mov	eax, dword [bx + 0x0102] */
		"\x66\x8b\x1b",	/* mov	bx, word [ebx] */
		"\x66\x89\xd1",	/* mov	cx, dx */
		"\x66\x87\x1b",	/* xchg	word [ebx], bx */
#if 1
		"\x9b",		/* wait */
		"\x0f\x09",	/* wbinvd */
		"\x0f\x30",	/* wrmsr */
		"\x0f\xc1\xd8",	/* xadd	eax, ebx */
		"\x0f\xc0\xca",	/* xadd	dl, cl */
		"\x92",		/* xchg	eax, edx */
		"\x86\x10",	/* xchg	byte [eax], dl */
		"\xd7",		/* xlat */
		"\x81\xf3\x44\x43\x42\x41",	/* xor	ebx, 0x41424344 */
		"\x80\x35\x44\x43\x42\x41\xf0",	/* xor	byte [0x41424344], 0xf0 */

		"\x0f\xa4\xc2\x0c",	/* shld	edx, eax, 12 */
		"\x0f\xad\xcb",		/* shdr	ebx, ecx, cl */
		"\xd3\xe8",	/* shr	eax, cl */
		"\x0f\x01\x0d\x34\x80\x04\x08",	/* sidt	[0x08048034] */
		"\xf9",		/* stc */
		"\xfd",		/* std */
		"\xfb",		/* sti */
		"\xab",		/* stosd */
		"\x0f\x00\x0d\x34\x80\x04\x08",	/* str	[0x08048034] */
		"\x2d\x08\x00\x00\x00",	/* sub	eax, 8 */
		"\x29\xd1",	/* sub	ecx, edx */
		"\xa8\xff",	/* test	al, 0xff */
		"\x0f\x0b",	/* ud2 */
		"\x0f\x00\x20",	/* verr	[eax] */
		"\x0f\x00\x2d\x34\x80\x04\x08",	/* verw	[0x08048034] */

		"\xc3",		/* ret */
		"\xc2\x02\x01",	/* ret	0x0102 */
		"\xd1\xc0",	/* rol	eax, 1 */
		"\xd3\xc2",	/* rol	edx, cl */
		"\xc1\xc8\x0c",	/* ror	eax, 12 */
		"\x0f\xaa",	/* rsm */
		"\x9e",		/* sahf */
		"\x19\xd0",	/* sbb	eax, edx */
		"\x80\xda\x0a",	/* sbb	dl, 10 */
		"\xae",		/* scasb */
		"\x0f\x94\xc0",	/* setz	al */
		"\xd3\xe3",	/* shl	ebx, cl */
		"\x1f",		/* pop	ds */
		"\x0f\xa9",	/* pop	gs */
		"\x68\x41\x41\x41\x41",	/* push	0x41414141 */
		"\x61",		/* popa */
		"\x9d",		/* popf */
		"\x50",		/* push	eax */
		"\x1e",		/* push	ds */
		"\x0f\xa0",	/* push	fs */
		"\x60",		/* pusha */
		"\x9c",		/* pushf */
		"\xd1\xd3",	/* rcl	ebx */
		"\xd3\xd0",	/* rcl	eax, cl */
		"\xc1\xd2\x04",	/* rcl	edx, 4 */
		"\xc1\xdb\x03",	/* rcr	ebx, 3 */
		"\x0f\x32",	/* rdmsr */
		"\x0f\x33",	/* rdpmc */
		"\x0f\x31",	/* rdtsc */

		"\x0f\xbe\xc2",		/* movsx	eax, dl */
		"\x0f\xb6\x15\x44\x43\x42\x41",	/* movzx	edx, byte [0x41424344} */
		"\xe6\x60",		/* out	0x60, al */
		"\xa4",			/* movsb */
		"\xa5",			/* movsd */
		"\xf7\xe2",		/* mul	edx */
		"\xf6\xd8",		/* neg	al */
		"\x90",			/* nop */
		"\xf7\x15\x44\x43\x42\x41",	/* not	dword [0x41424344] */
		"\x0b\x14\x85\x44\x43\x42\x41",	/* or	edx, dword [4*eax + 0x41424344] */
		"\xef",			/* out	dx, eax */
		"\x6e",			/* outsb */
		"\x58",			/* pop	eax */
		"\x8f\x05\x44\x43\x42\x41",	/* pop	dword [0x41424344] */

		"\x8e\xc8",		/* mov     cs, eax */
		"\x8c\xdb",		/* mov     ebx, ds */
		"\x8e\x0d\x44\x43\x42\x41",	/* mov     cs, word [0x41424344] */
		"\x8c\x05\x49\x48\x47\x46",	/* mov     word [0x46474849], es */

		"\x0f\x22\xc0",		/* mov     cr0, eax */
		"\x0f\x20\xc8",		/* mov     eax, cr1 */
		"\x0f\x23\xf2",		/* mov     dr6, edx */
		"\x0f\x21\xf9",		/* mov     ecx, dr7 */

		"\xa3\x44\x43\x42\x41",	/* mov     [0x41424344], eax */
		"\xa1\x84\x83\x82\x81",	/* mov     eax, [0x81828384] */

		"\x0f\x03\x18",		/* lsl     ebx, [eax] */
		"\x89\xc3",		/* mov     ebx, eax */
		"\x88\xe9",		/* mov     cl, ch */
		"\xb2\x61\xba",		/* mov     dl, 0x61 */
		"\xba\x61\x61\x61\x61",	/* mov     edx, 0x61616161 */

		"\x9f",			/* lahf */
		"\x0f\x02\xc3",		/* lar	eax, ebx */
		"\x0f\x02\x08",		/* lar	ecx, [eax] */
		"\x8d\x04\x8d\x00\x00\x00\x00",	/* lea	eax, [4*ecx] */
		"\xc9",			/* leave */
		"\x0f\x01\x13",		/* lgdt	[ebx] */
		"\x0f\x00\x11",		/* lldt	[ecx] */
		"\x0f\x01\x32",		/* lmsw	[edx] */
		"\xe2\x03",		/* loop 3 */
		"\xac",			/* lodsb */
		"\x79\x00",		/* jns	0 */
		"\x0f\x89\x41\x42\x43\x44",	/* jns	0x44434241 */
		"\xff\xe0",		/* jmp	eax */
		"\xea\x04\x03\x02\x01\x41\x40",	/* ljmp   $0x4041,$0x1020304 */
		"\xff\x20",		/* jmp	[eax] */
		"\xff\x25\x44\x43\x42\x41",	/* jmp	[0x41424344] */
		"\xe5\x60",		/* in	eax, 0x60 */
		"\xed",			/* in	eax, dx */
		"\x40",			/* inc	eax */
		"\xcc",			/* int3 */
		"\xcd\x80",		/* int	0x80 */
		"\xcf",			/* iret */
		"\x69\x08\x64\x00\x00\x00",	/* imul    ecx, [eax], 100 */
		"\x0f\xaf\x1d\x44\x43\x42\x41",	/* imul    ebx, dword [0x41424344] */
		"\x69\xc8\x64\x00\x00\x00",	/* imul    ecx, eax, 100 */
		"\xf7\xe9",	/* imul	ecx */
		"\x0f\xaf\xc2",	/* imul    eax, edx */
		"\xf6\xe9",	/* imul    cl */
		"\xf7\x2d\x44\x43\x42\x41",	/* imul    dword [0x41424344] */
		"\xc8\x00\x01\x01",	/* enter 0x0100, 1 */
		"\xf6\xf2",	/* div	dl */
		"\xf7\x35\x44\x43\x42\x41",	/* div	dword [0x41424344] */
		"\x48",		/* dec     eax */
	    	"\xff\x08",	/* dec     dword [eax] */
		"\xfe\x0d\x44\x43\x42\x41",	/* dec     byte [0x41424344] */
		"\xa6",		/* cmpsb */
		"\xa7",		/* cmpsd */
		"\x0f\xb1\xd8",	/* cmpxchg eax, ebx */
		"\x0f\xc7\x0d\x44\x43\x42\x41", /* cmpxchg8b       [0x41424344] */
		"\x3d\x40\x30\x20\x10",	/* cmp     eax, 0x10203040 */
		"\x38\x25\x44\x43\x42\x41",	/* cmp     byte [0x41424344], ah */
		"\x38\xfc",	/* cmp	ah, bh */
		"\x39\xd8",	/* cmp	eax, ebx */
		"\x38\xd8",	/* cmp	al, bl */
		"\x0f\x49\xc3",	/* cmovns %ebx,%eax */
		"\x98",
		"\x99",
		"\xf8",
		"\xfc",
		"\xfa",
		"\x0f\x06",
		"\xf5",
		"\x9a\x43\x42\x41\x40\x34\x12",	/* lcall  $0x1234,$0x40414243 */
		"\x01\x1c\x42",		/* add %ebx,(%edx,%eax,2) */
		"\x01\x9c\x51\x44\x43\x42\x41",	/* add [edx*2 + ecx + 0x41424344], ebx */
		"\x03\x04\xd0",		/* add eax, [edx * 8 + eax] */
		"\xe8\x01\x02\x03\x04",	/* call ... */
		"\x0f\xbb\xd8",		/* btc	eax, ebx */
		"\x0f\xa3\xd8",		/* bt      eax, ebx */
		"\x0f\xba\xe0\x7f",	/* bt      eax, 0x7f */
		"\x05\x40\x30\x20\x10",	/* add	eax, 0x10203040 */
		"\x0f\xbc\xc3",		/* bsf     eax, ebx */
		"\x0f\xbc\x04\xd5\x00\x00\x00\x00",	/* bsf     eax, [edx * 8] */
		"\x0f\xc8",		/* bswap   eax */
#endif
		NULL,
	};

	ia32_instruction	inst_s;
	ia32_instruction *	inst;

	int		n;
	unsigned int	amount;
	FILE *		bfp;
	unsigned char	buf[4096];


	bfp = fopen ("test2", "rb");
	if (bfp == NULL) {
		perror ("fopen");

		exit (EXIT_FAILURE);
	}

	amount = fread (buf, 1, sizeof (buf), bfp);
	n = 0;

	do {
		inst = ia32_decode_instruction (&buf[n], &inst_s);
		if (inst == NULL) {
			fprintf (stderr, "failed to decode\n");

			exit (EXIT_FAILURE);
		}

		printf ("0x%04x", n);
		ia32_print (inst);

		n += inst->length;
	} while (n < amount);

#if 0
	for (n = 0 ; tests[n] != NULL ; ++n) {
		inst = ia32_decode_instruction (tests[n], &inst_s);

		if (inst == NULL) {
			fprintf (stderr, "doh!\n");

			continue;
		}

		ia32_print (inst);
	}
#endif

	exit (EXIT_SUCCESS);
}

#endif

